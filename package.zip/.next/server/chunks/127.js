"use strict";
exports.id = 127;
exports.ids = [127];
exports.modules = {

/***/ 9127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hassanmojab_react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(650);
/* harmony import */ var _hassanmojab_react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_hassanmojab_react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6729);
/* harmony import */ var react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);






const Datepicker = ({ title , price  })=>{
    const persianToday = (0,react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_4__.utils)("fa").getToday();
    const defaultRange = {
        from: persianToday,
        to: null
    };
    const { 0: selectedDayRange , 1: setSelectedDayRange  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(defaultRange);
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const fromDay = selectedDayRange.from;
    const tounrooz = selectedDayRange.to;
    var fromDayArray = Object.keys(fromDay).map((key)=>[
            key,
            fromDay[key]
        ]
    );
    if (tounrooz) {
        var tounroozArray = Object.keys(tounrooz).map((key)=>[
                key,
                tounrooz[key], 
            ]
        );
    }
    if (fromDayArray[0].includes("year")) {
        testFrom = `${fromDayArray[0][1]}/${fromDayArray[1][1]}/${fromDayArray[2][1]}`;
    } else {
        var testFrom = `${fromDayArray[2][1]}/${fromDayArray[1][1]}/${fromDayArray[0][1]}`;
    }
    if (tounrooz) {
        var testTo = `${tounroozArray[2][1]}/${tounroozArray[1][1]}/${tounroozArray[0][1]}`;
    }
    async function purchaseSucces() {
        var myHeaders = new Headers();
        if (localStorage.getItem("Authorization")) {
            myHeaders.append("Authorization", localStorage.getItem("Authorization"));
        }
        var formData = new FormData();
        formData.append("code", route.query.id);
        formData.append("dates[0]", testFrom);
        formData.append("dates[1]", testTo);
        const option = {
            method: "POST",
            headers: myHeaders,
            body: formData,
            redirect: "follow"
        };
        await fetch("https://bsite.net/aradshamsi26/api/Estate/AddRequest", option).then((res)=>res.json()
        ).then((result)=>console.log(result)
        ).catch((error)=>console.log(error)
        );
        route.push("/order");
    }
    const orderHandler = ()=>{
        const orders = document.getElementById("d-none-o");
        const change = document.getElementById("orders");
        if (orders) {
            change.style.visibility = "visible";
            change.style.opacity = "1";
            orders.style.opacity = "1";
            orders.style.height = "350px";
        } else defaultHandler;
    };
    const defaultHandler = ()=>{
        setSelectedDayRange(defaultRange);
        const orders = document.getElementById("orders");
        orders.style.opacity = "1";
    };
    const forFooter = ()=>{
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "footer-calendar",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: "calendar-footer-btn",
                    onClick: defaultHandler,
                    children: "پاک کردن!"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "calendar-footer-btn-submit",
                    onClick: orderHandler,
                    children: "ثبت کردن"
                })
            ]
        }));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hassanmojab_react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_1__.Calendar, {
                calendarClassName: "responsive-calendar calendar",
                value: selectedDayRange,
                onChange: setSelectedDayRange,
                colorPrimary: "#018aeb",
                minimumDate: (0,react_modern_calendar_datepicker__WEBPACK_IMPORTED_MODULE_4__.utils)("fa").getToday(),
                colorPrimaryLight: "rgba(75, 207, 250, 0.8)",
                locale: "fa",
                renderFooter: forFooter,
                shouldHighlightWeekends: true
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-none-order text-center-o",
                id: "orders",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "orders",
                    children: tounrooz === null ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-center",
                        id: "dauern",
                        children: "لطفا یک بازه را انتخاب کنید"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "d-none-o",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                children: "جزییات سفارش"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                children: [
                                    "شما درخواست رزرو ",
                                    title,
                                    " را به مدت",
                                    " ",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "fw-bold",
                                        children: [
                                            tounrooz && tounrooz.day > fromDay.day ? tounrooz.day - fromDay.day : tounrooz.month > 6 ? tounrooz.day + 30 - fromDay.day : tounrooz.day + 31 - fromDay.day,
                                            " "
                                        ]
                                    }),
                                    "شب داده اید"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "fs-1",
                                children: [
                                    "قابل پرداخت",
                                    " ",
                                    tounrooz && tounrooz.day > fromDay.day ? (tounrooz.day - fromDay.day) * price : tounrooz.month > 6 ? (tounrooz.day + 30 - fromDay.day) * price : (tounrooz.day + 31 - fromDay.day) * price
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                className: "to-order",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: " آیا مایل به ادامه هستین؟"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "btn btn-success",
                                                onClick: purchaseSucces,
                                                children: "ادامه"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "btn btn-cancel",
                                                onClick: defaultHandler,
                                                children: [
                                                    " ",
                                                    "انصراف"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Datepicker);


/***/ })

};
;