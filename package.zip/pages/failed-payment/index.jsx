const FailedPayment = () => {
  return <div>Payment Failed</div>;
};
export default FailedPayment;
