const SuccessPayment = () => {
  return <div>Success Payment </div>;
};
export default SuccessPayment;
